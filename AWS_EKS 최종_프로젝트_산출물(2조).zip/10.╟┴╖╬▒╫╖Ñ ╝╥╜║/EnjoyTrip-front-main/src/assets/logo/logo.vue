<script setup>
const props = defineProps({
  width: { type: String, default: "100px" },
  height: { type: String, default: "70px" },
  color: { type: String, default: "black" },
})

const colorState = {
  black: "#000000",
  blue: "#68d2df",
}
</script>

<template>
  <svg xmlns:mydata="http://www.w3.org/2000/svg" mydata:contrastcolor="11111f" mydata:template="Contrast"
    mydata:presentation="2.5" mydata:layouttype="undefined" mydata:specialfontid="undefined" mydata:id1="063"
    mydata:id2="1054" mydata:companyname="Enjoy Trip" mydata:companytagline="" version="1.1"
    xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="100 100 350 270"
    :width="props.width" :height="props.height" style="margin: auto 10px;" >
    <g :fill="colorState[props.color]" fill-rule="none" stroke="none" stroke-width="1" stroke-linecap="butt"
      stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none"
      font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal" >
      <g
        data-paper-data="{&quot;isGlobalGroup&quot;:true,&quot;bounds&quot;:{&quot;x&quot;:83.67542756430626,&quot;y&quot;:175.7772646917177,&quot;width&quot;:382.64914487138753,&quot;height&quot;:118.44596018833684}}">
        <g data-paper-data="{&quot;stacked&quot;:true,&quot;isPrimaryText&quot;:true}" fill-rule="nonzero"
          id="element-id-74942">
          <path
            d="M251.94119,227.95152v-51.10345h33.19508v9.19419h-22.78239v10.89271h19.20072v9.23111h-19.20072v12.25892h22.78239v9.52651z"
            data-paper-data="{&quot;glyphName&quot;:&quot;E&quot;,&quot;glyphIndex&quot;:0,&quot;firstGlyphOfWord&quot;:true,&quot;word&quot;:1,&quot;line&quot;:1,&quot;firstGlyphOfFirstLine&quot;:true}"
            id="element-id-58247"></path>
          <path
            d="M323.16846,227.95152l-18.60993,-36.51829v36.51829h-10.19115v-51.10345h13.51435l17.31757,34.45052v-34.45052h10.22807v51.10345z"
            data-paper-data="{&quot;glyphName&quot;:&quot;N&quot;,&quot;glyphIndex&quot;:1,&quot;word&quot;:1,&quot;line&quot;:1}"
            id="element-id-42301"></path>
          <path
            d="M369.36095,214.031c0,5.39097 -1.36005,9.24958 -4.08015,11.57582c-2.7201,2.32624 -6.98488,3.48936 -12.79432,3.48936c-1.25543,0 -3.00319,-0.18462 -5.24327,-0.55387c-2.24008,-0.36924 -4.09861,-0.84926 -5.57559,-1.44005l3.1755,-9.26804c0.78772,0.41848 2.04931,0.86157 3.78476,1.32928c1.73545,0.46771 3.0955,0.70156 4.08015,0.70156c1.82161,0 3.13858,-0.24616 3.95092,-0.73849c0.81234,-0.49233 1.39082,-1.3539 1.73545,-2.58471c0.34463,-1.23082 0.51694,-3.00319 0.51694,-5.31712v-34.37667h10.44962z"
            data-paper-data="{&quot;glyphName&quot;:&quot;J&quot;,&quot;glyphIndex&quot;:2,&quot;word&quot;:1,&quot;line&quot;:1}"
            id="element-id-73129"></path>
          <path
            d="M422.23677,202.3998c0,8.88649 -1.87699,15.5452 -5.63098,19.97613c-3.75399,4.43093 -9.21265,6.6464 -16.376,6.6464c-7.55721,0 -13.11434,-2.33239 -16.67139,-6.99718c-3.55706,-4.66479 -5.33558,-11.20657 -5.33558,-19.62535c0,-8.46801 1.77853,-15.0221 5.33558,-19.66227c3.55706,-4.64017 9.11419,-6.96026 16.67139,-6.96026c7.60644,0 13.17588,2.32009 16.70832,6.96026c3.53244,4.64017 5.29866,11.19426 5.29866,19.66227zM411.49176,202.3998c0,-6.05561 -0.85542,-10.46808 -2.56625,-13.23742c-1.71083,-2.76933 -4.6094,-4.154 -8.69571,-4.154c-4.08631,0 -6.98488,1.38467 -8.69571,4.154c-1.71083,2.76933 -2.56625,7.18181 -2.56625,13.23742c0,6.05561 0.86772,10.46808 2.60317,13.23742c1.73545,2.76933 4.62171,4.154 8.65878,4.154c4.08631,0 6.98488,-1.38467 8.69571,-4.154c1.71083,-2.76933 2.56625,-7.18181 2.56625,-13.23742z"
            data-paper-data="{&quot;glyphName&quot;:&quot;O&quot;,&quot;glyphIndex&quot;:3,&quot;word&quot;:1,&quot;line&quot;:1}"
            id="element-id-88533"></path>
          <path
            d="M450.29936,208.45541v19.49611h-10.48655v-19.27457l-15.98829,-31.82888h11.37273l9.9696,21.37926l10.19115,-21.37926h10.96656z"
            data-paper-data="{&quot;glyphName&quot;:&quot;Y&quot;,&quot;glyphIndex&quot;:4,&quot;lastGlyphOfWord&quot;:true,&quot;word&quot;:1,&quot;line&quot;:1,&quot;lastGlyphOfFirstLine&quot;:true}"
            id="element-id-12565"></path>
          <path d="M278.0837,252.6458v41.57694h-10.4127v-41.57694h-15.72982v-9.52651h41.87233v9.52651z"
            data-paper-data="{&quot;glyphName&quot;:&quot;T&quot;,&quot;glyphIndex&quot;:5,&quot;firstGlyphOfWord&quot;:true,&quot;word&quot;:2,&quot;line&quot;:2,&quot;firstGlyphOfSecondLine&quot;:true}"
            id="element-id-8514"></path>
          <path
            d="M296.32438,294.22274l13.66205,-20.56692c-3.3232,-0.66464 -5.91407,-2.29547 -7.7726,-4.89249c-1.85853,-2.59702 -2.7878,-6.08638 -2.7878,-10.46808c0,-5.39097 1.50775,-9.26804 4.52325,-11.6312c3.0155,-2.36317 7.83414,-3.54475 14.45592,-3.54475h18.60993v51.10345h-10.44962v-19.34841h-5.2802l-13.03433,19.34841zM309.98643,258.73833c0,1.94469 0.27693,3.38474 0.8308,4.32016c0.55387,0.93542 1.45852,1.62468 2.71395,2.06777c1.25543,0.44309 3.05242,0.66464 5.39097,0.66464h7.64336v-13.62512h-8.08646c-3.02781,0 -5.20019,0.44309 -6.51717,1.32928c-1.31697,0.88619 -1.97546,2.63394 -1.97546,5.24327z"
            data-paper-data="{&quot;glyphName&quot;:&quot;Я&quot;,&quot;glyphIndex&quot;:6,&quot;word&quot;:2,&quot;line&quot;:2}"
            id="element-id-81633"></path>
          <path
            d="M370.94871,294.22274h-24.66554v-8.01261h7.12642v-35.07823h-7.12642v-8.01261h24.66554v8.01261h-7.0895v35.07823h7.0895z"
            data-paper-data="{&quot;glyphName&quot;:&quot;I&quot;,&quot;glyphIndex&quot;:7,&quot;word&quot;:2,&quot;line&quot;:2}"
            id="element-id-46845"></path>
          <path
            d="M417.58429,260.25224c0,6.15408 -1.44621,10.7204 -4.33862,13.69897c-2.89242,2.97857 -7.58798,4.46786 -14.08668,4.46786h-8.49262v15.80367h-10.4127v-51.10345h19.20072c5.78483,0 10.25269,1.34774 13.40358,4.04323c3.15089,2.69549 4.72633,7.05872 4.72633,13.08972zM406.83928,260.32609c0,-2.88011 -0.79388,-4.96019 -2.38163,-6.24023c-1.58775,-1.28005 -4.4494,-1.92007 -8.58494,-1.92007h-5.20635v17.16987h4.24631c3.81553,0 6.45563,-0.26463 7.9203,-0.79388c1.46467,-0.52925 2.49855,-1.42159 3.10165,-2.67702c0.6031,-1.25543 0.90465,-3.10165 0.90465,-5.53867z"
            data-paper-data="{&quot;glyphName&quot;:&quot;P&quot;,&quot;glyphIndex&quot;:8,&quot;lastGlyphOfWord&quot;:true,&quot;word&quot;:2,&quot;line&quot;:2,&quot;lastGlyphOfSecondLine&quot;:true}"
            id="element-id-93044"></path>
        </g>
        <g data-paper-data="{&quot;selectedEffects&quot;:{&quot;container&quot;:&quot;&quot;,&quot;transformation&quot;:&quot;&quot;,&quot;pattern&quot;:&quot;&quot;},&quot;initialText&quot;:&quot;ET&quot;,&quot;fillRule&quot;:&quot;nonzero&quot;,&quot;bounds&quot;:{&quot;x&quot;:83.67542756430626,&quot;y&quot;:175.7772646917177,&quot;width&quot;:117.3435605588717,&quot;height&quot;:118.44596018833684},&quot;isIcon&quot;:&quot;true&quot;,&quot;iconType&quot;:&quot;initial&quot;,&quot;iconStyle&quot;:&quot;standalone&quot;,&quot;rawInitialId&quot;:1087,&quot;monogramSpecial&quot;:&quot;emblem&quot;,&quot;suitableAsStandaloneIcon&quot;:true}"
          fill-rule="evenodd" id="element-id-73019">
          <g data-paper-data="{&quot;isPathIcon&quot;:true}" id="element-id-50264">
            <path
              d="M140.98801,294.22322c-31.88399,-1.054 -57.31258,-27.14099 -57.31258,-59.15698c0,-32.14799 25.42859,-58.23498 57.31258,-59.28898v10.54c-26.08699,1.054 -46.77238,22.39799 -46.77238,48.74898c0,3.689 0.3953,7.378 1.1858,10.935l45.58658,-26.34999v12.253l-42.02929,24.24199c7.6413,15.81099 23.45229,26.87799 42.02929,27.53699z"
              id="element-id-49466"></path>
            <path
              d="M147.65801,186.55726c5.525,0.135 10.915,1.348 15.89999,3.234v104.43196c3.773,-1.213 7.412,-2.83 10.78,-4.582v-94.05497c5.929,4.177 10.915,9.702 14.553,16.03499h12.128c-9.163,-20.61699 -29.50999,-35.03499 -53.36098,-35.84399z"
              id="element-id-86262"></path>
          </g>
        </g>
        <path d="M221.38787,294.22274v-118.44547h1.94894v118.44547z"
          data-paper-data="{&quot;isShapeTextSeparator&quot;:true}" fill-rule="nonzero" id="element-id-42787"></path>
      </g>
    </g>
    <rect data-element-id="element-id-74942" stroke-width="2" fill="transparent"
      class="invisible-element-box grouping-element" x="252" y="176" width="214" height="118"
      data-element-name="isPrimaryText"></rect>
    <rect data-element-id="element-id-73019" stroke-width="2" fill="transparent"
      class="invisible-element-box grouping-element" x="84" y="176" width="117" height="118" data-element-name="isIcon">
    </rect>
    <rect data-element-id="element-id-50264" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="84" y="176" width="117" height="118"></rect>
    <rect data-element-id="element-id-49466" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="84" y="176" width="57" height="118"></rect>
    <rect data-element-id="element-id-86262" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="148" y="176" width="53" height="118"></rect>
    <rect data-element-id="element-id-88533" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="378" y="176" width="44" height="53"></rect>
    <rect data-element-id="element-id-12565" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="424" y="177" width="42" height="51"></rect>
    <rect data-element-id="element-id-8514" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="252" y="243" width="42" height="51"></rect>
    <rect data-element-id="element-id-42301" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="294" y="177" width="41" height="51"></rect>
    <rect data-element-id="element-id-81633" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="296" y="243" width="41" height="51"></rect>
    <rect data-element-id="element-id-93044" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="380" y="243" width="37" height="51"></rect>
    <rect data-element-id="element-id-58247" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="252" y="177" width="33" height="51"></rect>
    <rect data-element-id="element-id-73129" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="342" y="177" width="28" height="52"></rect>
    <rect data-element-id="element-id-46845" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="346" y="243" width="25" height="51"></rect>
    <rect data-element-id="element-id-42787" stroke-width="2" fill="transparent"
      class="invisible-element-box individual-element" x="221" y="176" width="2" height="118"></rect>
  </svg>
</template>

<style scoped></style>