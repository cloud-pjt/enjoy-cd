<script setup>
import { RouterView } from "vue-router";
import TheBottomBar from "@/components/layout/TheBottomBar.vue"
</script>

<template>
  <router-view></router-view>
  <TheBottomBar/>
</template>

<style scoped>

</style>