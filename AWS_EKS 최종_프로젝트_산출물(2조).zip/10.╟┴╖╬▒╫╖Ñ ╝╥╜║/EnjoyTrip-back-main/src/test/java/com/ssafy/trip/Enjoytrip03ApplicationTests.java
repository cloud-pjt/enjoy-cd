package com.ssafy.trip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Enjoytrip03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
